import random

from utils import clear, title, pause, countdown


def run(data):
    secret = ""

    for i in range(15):
        secret += str(random.randint(0, 9))

    title("REMEMBER THE NUMBERS")
    print()
    print()

    countdown(10, f"Remember this number:\n\n{secret}")

    clear()

    answer = input("Enter the number: ")

    if len(answer) != 15 or not answer.isdigit():
        print("Invalid number")
        pause()
        return data

    correct = 0

    for i in range(15):
        if answer[i] == secret[i]:
            correct += 1

    reward = correct * 5

    match = []

    for i in range(15):
        if answer[i] == secret[i]:
            match.append("✓")
        else:
            match.append("✗")

    clear()

    print(f"Number Order: {secret}")
    print(f"You:          {answer}")
    print(f"Match:        {' '.join(match)}")
    print()

    print(f"Correct digits: {correct}/15")
    print(f"Your Reward: {reward}")

    data["credits"] += reward
    data["games_played"] += 1

    if data["credits"] > data["highest_credits"]:
        data["highest_credits"] = data["credits"]

    pause()

    return data