import sys
import os
import json


ANDROID_PATH = "/storage/emulated/0/PynuxOS/packages/jackpot"

if os.path.exists(ANDROID_PATH):
    BASE_DIR = ANDROID_PATH
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))


if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)


from utils import clear, title, pause, load_json, save_json


SAVES_DIR = os.path.join(BASE_DIR, "Saves")

MAX_SLOTS = 3


DEFAULT_SAVE = {
    "_developer_message": "Why are you here? You know that if you change this, you will bear the burden of having lied to others.",
    "credits": 0,
    "games_played": 0,
    "jackpots": 0,
    "highest_credits": 0
}


def get_save_path(slot):
    return os.path.join(
        SAVES_DIR,
        f"save{slot}.json"
    )


def create_saves():

    if not os.path.exists(SAVES_DIR):
        os.makedirs(SAVES_DIR)

    for i in range(1, MAX_SLOTS + 1):

        path = get_save_path(i)

        if not os.path.exists(path):
            save_json(path, DEFAULT_SAVE.copy())


def load_slot(slot):
    return load_json(get_save_path(slot))


def save_slot(slot, data):
    save_json(get_save_path(slot), data)


def reset_slot(slot):
    save_json(
        get_save_path(slot),
        DEFAULT_SAVE.copy()
    )


def slot_empty(slot):

    data = load_slot(slot)

    return (
        data["credits"] == 0 and
        data["games_played"] == 0 and
        data["jackpots"] == 0
    )


# ==========================
# MENUS
# ==========================


def main_menu():

    while True:

        clear()
        title("HIT THE JACKPOT!")

        print("1. New Game")
        print("2. Save Slots")
        print()
        print("0. Exit")

        option = input("\nChoose: ")

        if option == "1":
            new_game()

        elif option == "2":
            save_slots()

        elif option == "0":
            break

        else:
            pause()


def new_game():

    clear()
    title("NEW GAME")

    empty_slots = []

    for i in range(1, MAX_SLOTS + 1):

        if slot_empty(i):
            empty_slots.append(i)


    if empty_slots:

        slot = empty_slots[0]

        print(f"Created new game in Slot {slot}")

        reset_slot(slot)

        pause()

        slot_menu(slot)


    else:

        print("All slots are occupied.")
        print()

        for i in range(1, MAX_SLOTS + 1):
            print(f"{i}. Overwrite Slot {i}")

        print("0. Cancel")

        choice = input("\nChoose: ")

        if choice in ["1", "2", "3"]:

            slot = int(choice)

            reset_slot(slot)

            slot_menu(slot)



def save_slots():

    while True:

        clear()
        title("SAVE SLOTS")


        for i in range(1, MAX_SLOTS + 1):

            data = load_slot(i)

            print(f"Slot {i}")
            print("----------------")
            print(f"Credits : {data['credits']}")
            print(f"Games   : {data['games_played']}")
            print(f"Jackpots: {data['jackpots']}")
            print()


        print("0. Back")

        choice = input("Choose slot: ")


        if choice in ["1", "2", "3"]:

            slot_menu(int(choice))

        elif choice == "0":
            break



def slot_menu(slot):

    while True:

        data = load_slot(slot)

        clear()
        title(f"SLOT {slot}")

        print(f"Credits : {data['credits']}")
        print(f"Games   : {data['games_played']}")
        print(f"Jackpots: {data['jackpots']}")

        print()

        print("1. Play")
        print("2. Delete Save")
        print("3. View Statistics")

        print()
        print("0. Back")


        choice = input("\nChoose: ")


        if choice == "1":

            game_menu(slot)


        elif choice == "2":

            reset_slot(slot)

            print("Save deleted.")

            pause()


        elif choice == "3":

            statistics(slot)


        elif choice == "0":

            break



def statistics(slot):

    data = load_slot(slot)

    clear()
    title("STATISTICS")


    print(f"Credits: {data['credits']}")
    print(f"Games Played: {data['games_played']}")
    print(f"Jackpots: {data['jackpots']}")
    print(f"Highest Credits: {data['highest_credits']}")


    pause()



def game_menu(slot):

    while True:

        data = load_slot(slot)

        clear()
        title("GAMES")


        print(f"Credits: {data['credits']}")
        print()

        print("1. Even or Odd?")
        print("2. Remember the Numbers")
        print("3. Guess The Number")
        print("4. Lucky Cards")
        print("5. Jackpot")

        print()
        print("0. Back")


        choice = input("\nChoose: ")


        if choice == "0":
            break

        elif choice == "1":

            from Games import even_or_odd

            data = even_or_odd.run(data)

            save_slot(slot, data)    
         
        elif choice == "2":
            
            from Games import remember_the_numbers
     
            data = remember_the_numbers.run(data)

            save_slot(slot, data)
        
        elif choice == "3":

            from Games import guess_the_number

            data = guess_the_number.run(data)

            save_slot(slot, data)
            
        elif choice == "4":
            
            from Games import lucky_cards
            
            data = lucky_cards.run(data)       
            
            save_slot(slot, data)      
            
        elif choice == "5":
            
            from Games import hit_the_jackpot
            
            data = hit_the_jackpot.run(data)
            
            save_slot(slot, data)


def run():

    create_saves()

    main_menu()

