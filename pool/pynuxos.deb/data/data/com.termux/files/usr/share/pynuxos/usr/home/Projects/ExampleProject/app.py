# ============================================
#          PynuxOS Example Project
# ============================================

# Welcome!
#
# This file shows the basic structure of a
# PynuxOS application.
#
# Every application MUST have a function
# called run().
#
# PynuxOS looks for that function when you
# execute the application.
#
# ============================================


def run():
    print("Hello from PynuxOS!")
    print()
    print("This is an example application.")
    print("Try editing this file!")
    print()
    print("Ideas:")
    print("- Change this message.")
    print("- Create variables.")
    print("- Ask the user for input.")
    print("- Create your own project.")
    print()
    input("Press Enter to exit...")
    return


# ============================================
# Notes
# ============================================
#
# 1. Do NOT rename run().
#
# 2. Always remember to include an __init__.py file so that the PynuxOS system knows it's a module.
#
# 2. PynuxOS executes:
#
#       run()
#
#    automatically.
#
# 3. You can create as many functions as you
#    want.
#
# Example:
#
# def hello():
#     print("Hello!")
#
# def run():
#     hello()
#
# ============================================