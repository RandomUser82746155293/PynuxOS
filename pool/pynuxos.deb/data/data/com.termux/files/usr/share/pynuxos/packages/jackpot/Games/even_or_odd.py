import random

from utils import clear, title, pause


def run(data):

    clear()
    title("EVEN OR ODD?")


    print("Choose:")
    print()
    print("1. Even")
    print("2. Odd")
    print()
    print("0. Back")


    choice = input("\nChoose: ")


    if choice == "0":
        return data


    if choice not in ["1", "2"]:
        print("Invalid option.")
        pause()
        return data


    number = random.randint(0, 9)

    data["games_played"] += 1


    print()
    print(f"Number: {number}")


    is_even = number % 2 == 0


    won = (
        (choice == "1" and is_even) or
        (choice == "2" and not is_even)
    )


    if won:

        print()
        print("You win!")
        print("+50 credits")

        data["credits"] += 50


        if data["credits"] > data["highest_credits"]:
            data["highest_credits"] = data["credits"]


    else:

        print()
        print("You lose.")


    pause()

    return data