import random

from utils import clear, title, pause


def run(data):

    clear()
    title("GUESS THE NUMBER")

    print("Guess a number between 0 and 9999.")
    print()

    try:
        guess = int(input("Your guess: "))
    except ValueError:
        print("\nInvalid number.")
        pause()
        return data

    if guess < 0 or guess > 9999:
        print("\nNumber must be between 0 and 9999.")
        pause()
        return data

    secret = random.randint(0, 9999)

    difference = abs(secret - guess)

    data["games_played"] += 1

    print()
    print(f"The number was: {secret}")
    print(f"Difference: {difference}")
    print()

    if difference == 0:

        reward = 300

        print("🎯 PERFECT HIT!")

    elif difference <= 100:

        reward = 150

        print("🔥 VERY CLOSE...")

    elif difference <= 1000:

        reward = 100

        print("🙂 CLOSE!")

    elif difference <= 5000:

        reward = 50

        print("😐 NOT BAD!")

    else:

        reward = 25

        print("💀 FAR AWAY!")

    print(f"+{reward} Credits")

    data["credits"] += reward

    if data["credits"] > data["highest_credits"]:
        data["highest_credits"] = data["credits"]

    pause()

    return data