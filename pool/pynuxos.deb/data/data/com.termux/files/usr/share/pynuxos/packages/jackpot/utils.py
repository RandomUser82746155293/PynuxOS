import os
import sys
import time
import json


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def type_effect(text, speed=0.05):
    for letter in text:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(speed)

    print()


def pause():
    input("\nPress ENTER to continue...")


def title(text):
    clear()

    print("==============================")
    print(text.center(30))
    print("==============================")
    print()


def load_json(path):
    with open(path, "r") as file:
        return json.load(file)


def save_json(path, data):
    with open(path, "w") as file:
        json.dump(data, file, indent=4)


def countdown(seconds, message=""):

    for i in range(seconds, 0, -1):

        clear()

        if message:
            print(message)
            print()

        print(f"Time: {i}")

        time.sleep(1)

    clear()


def dots_animation(text, seconds=2):

    print(text, end="", flush=True)

    for i in range(3):
        time.sleep(seconds / 3)
        print(".", end="", flush=True)

    print()