import urllib.request
import urllib.parse
import json




def wiki_search(query):

    url = (
        "https://es.wikipedia.org/w/api.php?"
        "action=opensearch&"
        f"search={urllib.parse.quote(query)}&"
        "limit=5&"
        "format=json"
    )

    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "PynuxOS"
        }
    )

    response = urllib.request.urlopen(request)

    data = json.loads(response.read())
    
           

    return data[1]
    
def wiki_article(title):
    
    url = (
    "https://es.wikipedia.org/w/api.php?"
    "action=query&"
    "format=json&"
    "prop=extracts&"
    "exintro=true&"
    "explaintext=true&"
    f"titles={urllib.parse.quote(title)}"
)

    request = urllib.request.Request(
    url,
    headers={
    "User-Agent": "PynuxOS"
    }
    )
    
    response = urllib.request.urlopen(request)
    data = json.loads(response.read())
    
    pages = data["query"]["pages"]
    
    page = list(pages.values())[0]
    
    text = page["extract"]
    
    paragraphs = text.split("\n")
    
    for paragraph in paragraphs:
        if paragraph.strip():
            print()
            print(paragraph.strip())
            print()
    

def run():

    search = input("\nSearch: ")
    results = wiki_search(search)

    if results:

        if results[0].lower() == search.lower():

            wiki_article(search)

        else:

            print("Did you mean:\n")

            for i, title in enumerate(results, start=1):
                print(f"{i}. {title}")

            print()

            try:
                choice = int(input("Choose: "))

                if 1 <= choice <= len(results):
                    wiki_article(results[choice - 1])

                else:
                    print("Invalid Option")

            except ValueError:
                print("Invalid input")

    else:

        print("No similar articles found.")
        print()
        print("Try using fewer words or checking the spelling.")