=========================================
        WELCOME TO THE TUTORIAL
=========================================

Read the files in this order:

1. PYTHON_BASICS.txt
   Learn the Python language.

2. app.py
   Learn how a PynuxOS application works.

After that...

Create your own projects!

Good luck!