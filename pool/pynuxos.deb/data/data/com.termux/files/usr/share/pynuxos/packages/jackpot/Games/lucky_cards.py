import random

from utils import clear, dots_animation, title, pause, type_effect


CARDS = {
    "joker": {
        "name": "Joker",
        "type": "lose",
        "value": -50,
        "weight": 5
    },

    "white": {
        "name": "White Card",
        "type": "nothing",
        "value": 0,
        "weight": 45
    },

    "king": {
        "name": "King",
        "type": "multiplier",
        "value": 2,
        "weight": 20
    },

    "queen": {
        "name": "Queen",
        "type": "reroll",
        "value": 0,
        "weight": 10
    },

    "heart": {
        "name": "Heart",
        "type": "reward",
        "value": 25,
        "weight": 30
    },

    "diamond": {
        "name": "Diamond",
        "type": "reward",
        "value": 30,
        "weight": 15
    },

    "spade": {
        "name": "Spade",
        "type": "reward",
        "value": 50,
        "weight": 10
    },

    "clover": {
        "name": "Four Leaf Clover",
        "type": "special",
        "value": 200,
        "weight": 1
    }
}


for number in range(1, 11):
    CARDS[f"red_{number}"] = {
        "name": f"red_{number}",
        "type": "number",
        "value": number * 5,
        "weight": 10
        }
    
    CARDS[f"black_{number}"] = {
        "name": f"black_{number}",
        "type": "number",
        "value": -(number * 5),
        "weight": 10
        }
        
DECK = list(CARDS.keys())        

WEIGHTS = []

for card in DECK:
    WEIGHTS.append(CARDS[card]["weight"])
    
def create_deck():
    deck = []

    for i in range(63):
        card_id = random.choices(
            DECK,
            weights=WEIGHTS
        )[0]

        deck.append(card_id)

    random.shuffle(deck)

    return deck    
    
CARD_EMOJIS = {
    "joker": "🃏",
    "white": "⬜",
    "king": "🤴",
    "queen": "👸",
    "heart": "❤️",
    "diamond": "♦️",
    "spade": "♠️",
    "clover": "🍀"
}    

for i in range(1, 11):
    CARD_EMOJIS[f"red_{i}"] = "🔴"
    CARD_EMOJIS[f"black_{i}"] = "⚫"
   


def run(data):        

    deck = create_deck()

    cards_used = 0
    round_credits = 0
    king_active = False


    while deck:

        clear()
        title("LUCKY CARDS")

        print()
        print(f"Cards Used: {cards_used}")
        print(f"Earned Credits: {round_credits}")

        input("\nPress Enter to Start")


        # Create 7 cards
        visible_cards = []

        for i in range(7):
            if deck:
                visible_cards.append(deck.pop())


        # Hidden cards
        card_status = ["🂠"] * len(visible_cards)


        # Card selection
        while "🂠" in card_status:

            clear()
            title("LUCKY CARDS")

            print()
            print(f"Cards Used: {cards_used}")
            print(f"Earned Credits: {round_credits}")

            print()

            for i in range(len(card_status)):
                print(f"{i + 1}. {card_status[i]}")


            try:
                choice = int(input("\nChoose: "))

            except ValueError:
                print("Invalid input!")
                pause()
                continue


            if choice < 1 or choice > len(visible_cards):
                print("Invalid Card!")
                pause()
                continue


            if card_status[choice - 1] != "🂠":
                print("Card already used!")
                pause()
                continue


            card_id = visible_cards[choice - 1]
            card = CARDS[card_id]


            card_status[choice - 1] = CARD_EMOJIS[card_id]


            clear()
            dots_animation("Revealing")

            print()
            print(f"You got: {CARD_EMOJIS[card_id]} {card['name']}")
            

            print()


            # KING
            if card["type"] == "multiplier":

                print("The King offers a x2 multiplier for your next card!")

                choice = input("Accept? (y/n): ").lower()

                if choice == "y":

                    king_active = True
                    print("Multiplier accepted!")

                else:

                    print("Multiplier rejected.")


            # QUEEN
            elif card["type"] == "reroll":

                print("The Queen added 2 extra cards!")

                for i in range(2):

                    extra_card = random.choices(
                        DECK,
                        weights=WEIGHTS
                    )[0]

                    visible_cards.append(extra_card)
                    card_status.append("🂠")


            # OTHER CARDS
            else:
                value = card["value"]
                if king_active:
                    value *= 2
                    king_active = False
                    print("King multipler applied! x2")
                
                round_credits += value
                
                print(f"Reward: {value}")
                


            cards_used += 1

            pause()



        # ROUND COMPLETE

        clear()
        title("ROUND COMPLETE")

        print()
        print(f"Round Credits: {round_credits}")

        print()
        print("1. Continue")
        print("2. Take Credits")

        choice = input("\nChoose: ")


        if choice == "1":

            continue


        elif choice == "2":

            data["credits"] += round_credits
            return data



    clear()
    title("GAME COMPLETE")

    print()
    print("You used all cards!")
    print(f"Total Credits: {round_credits}")

    pause()

    data["credits"] += round_credits

    return data