def run():
    print("====================")
    print(" PynuxOS Calculator ")
    print("====================")

    while True:
        print("\nOperaciones:")
        print("1. Sumar")
        print("2. Restar")
        print("3. Multiplicar")
        print("4. Dividir")
        print("5. Salir")

        opcion = input("Selecciona una opción: ")

        if opcion == "5":
            print("Cerrando calculadora...")
            break

        try:
            numero1 = float(input("Primer número: "))
            numero2 = float(input("Segundo número: "))

            if opcion == "1":
                print("Resultado:", numero1 + numero2)

            elif opcion == "2":
                print("Resultado:", numero1 - numero2)

            elif opcion == "3":
                print("Resultado:", numero1 * numero2)

            elif opcion == "4":
                if numero2 == 0:
                    print("∞")
                else:
                    print("Resultado:", numero1 / numero2)

            else:
                print("Opción inválida.")

        except ValueError:
            print("Introduce números válidos.")