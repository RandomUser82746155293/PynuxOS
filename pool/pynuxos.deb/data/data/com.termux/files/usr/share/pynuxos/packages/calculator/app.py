def run():
    print("====================")
    print(" PynuxOS Calculator ")
    print("====================")

    while True:
        print("\nOperations:")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Exit")

        option = input("Select an option: ")

        if option == "5":
            print("Closing calculator...")
            break

        try:
            number1 = float(input("First number: "))
            number2 = float(input("Second number: "))

            if option == "1":
                print("Result:", number1 + number2)

            elif option == "2":
                print("Result:", number1 - number2)

            elif option == "3":
                print("Result:", number1 * number2)

            elif option == "4":
                if number2 == 0:
                    print("∞")
                else:
                    print("Result:", number1 / number2)

            else:
                print("Invalid option.")

        except ValueError:
            print("Enter valid numbers.")