import random
import time
import sys

from utils import clear, title, pause, dots_animation, type_effect

messages = {
    "message1": "Better luck next time",
    "message2": "Relax, money isn't everything.",
    "message3": "Don't give up, you'll make it",
    "message4": "Im sorry bro",
    "message5": "Loading Message...  ERROR: i'm lazy",
    "message6": "It's not easy, 0.1% chance of the Jackpot"
    }



def run(data):

    clear()
    title("JACKPOT")

    print()
    print("Entry Cost: 500 Credits")
    print()

    if data["credits"] < 500:
        print("You need at least 500 Credits to play.")
        pause()
        return data

    input("Press Enter to Play...")

    data["credits"] -= 500

    number = random.randint(0, 999)
    digits = str(number).zfill(3)

    while digits:

        clear()
        print()
        title("JACKPOT")
        print()

        for digit in digits:
            sys.stdout.write(digit)
            sys.stdout.flush()
            time.sleep(1)

        print()

        if digits == "777":

            time.sleep(3)

            print("JACKPOT!!!")
            print("JACKPOT!!!")
            print("JACKPOT!!!")
            print("JACKPOT!!!")
            print("JACKPOT!!!")

            time.sleep(1)

            print()
            print("You Win...")

            time.sleep(3)

            print()
            print("$0.01!")

            time.sleep(1)

            print()
            print("JUST KIDDING!")

            time.sleep(0.5)

            print()
            print("+10,000 Credits because why not")

            data["credits"] += 10000

            pause()
            return data

        elif digits == "666":

            time.sleep(5)

            print("...")

            time.sleep(3)

            print("U N L U C K Y")

            time.sleep(10)

            with open("what.txt", "w") as f:
                f.write("I dont know what to say...\n")
                f.write("J-just ignore that\n")
                f.write("I'm sorry")

            raise KeyError(666)

        elif digits[0] == digits[1] == digits[2]:

            print("Triple digit!")

            time.sleep(0.5)

            print("+60 Credits")

            data["credits"] += 60

            pause()
            return data

        elif (
            digits[0] == digits[1]
            or digits[1] == digits[2]
        ):

            print("Double digit!")

            time.sleep(0.5)

            print("+30 Credits")

            data["credits"] += 30

            pause()
            return data

        else:

            random_message = random.choice(list(messages.values()))

            print(random_message)

            pause()

            return data