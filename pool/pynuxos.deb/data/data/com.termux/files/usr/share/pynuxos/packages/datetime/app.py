import datetime

def run():
    now = datetime.datetime.now()

    days = [
        "Monday", "Tuesday", "Wednesday",
        "Thursday", "Friday", "Saturday", "Sunday"
    ]

    print("----- Date & Time -----")
    print("Day  :", days[now.weekday()])
    print("Date :", now.strftime("%d/%m/%Y"))
    print("Time :", now.strftime("%H:%M:%S"))
    print("-----------------------")