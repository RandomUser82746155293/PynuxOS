import os
import sys
import time
import shutil
import importlib
import random
import importlib.util


if os.path.exists("/storage/emulated/0/Pynux"):
    BASE_DIR = "/storage/emulated/0/Pynux"
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
USR_DIR = os.path.join(BASE_DIR, "usr")   

CURRENT_DIR = os.path.join(USR_DIR, "home")

PROTECTED_DIRS = [
    "bin",
    "home",
    "installed",
    "packages",
    "share",
    "tmp",
    "var"
]



def filesystem_not_found(USR_DIR):
    if not os.path.exists(USR_DIR):
        print("ERROR: usr folder not found.")
        sys.exit(1)
        
def help():
    print("Command list:")
    print(" - Version: tells you the console version")
    print(" - Updates: shows the updates of the console")
    print(" - Packages: shows the list of the packages that can be installed")
    print(" - About: tells you info of the console")
    print(" - helloworld: 'Hello World!'")
    print(" - typeeffect: returns the message with a typing effect")
    print(" - clear: clears the screen")
    print(" - pkg install <name>: installs a package")
    print(" - pkg uninstall <name>: deletes an installed package")
    print(" - goto <directory>: goes to the directory that you write")
    print(" - newfile <filename>: creates a new archive")
    print(" - newdir <dirname> creates a new directory, with option '-p' you can create a complete directory like: 'example/directory/name'")
    print(" - remove <file> removes an archive, with option -r you can delete directories")
    print(" - achlist <directory> shows the list of files or archives that are on the directory")
    print(" - view <file> views the content of an archive")
    print(" - edit: edits an archive")
    print(" - exit: closes PynuxOS")
    print(" - !help: shows this list")
    
def pkg_uninstall(package_name):
    installed_package = os.path.join(BASE_DIR, "installed", package_name)

    if os.path.exists(installed_package):
        shutil.rmtree(installed_package)
        print(f"{package_name} uninstalled successfully.")

    else:
        print("The package is not installed.")    


def Version():
    print("PynuxOS V1.0.0")
    
def Packages():
    print("Packages")
    print("-------------------")
    print("calculator: it's a calculator")
    print("jackpot: it's a game about a casino")
    print("datetime: shows the date and time")
    print("wiki: interacts with wikipedia")
    
def About():
    print("PynuxOS")    
    print("--ABOUT--")
    print("Author: RandomUser82746155293")
    print("Version: 1.0.0")
    print("Desc: A Python-based terminal environment for Termux")
    print(f"Your IP: {random.randint(0, 9)}.{random.randint(0, 999)}.{random.randint(0, 99)}.0 <-- this is random btw")
    
def Updates():
	print("v1.0.0")
	print("ACTUALLY the first stable version of PynuxOS")
	print("New commands")
	print("A file system, you can interact with it")
	print("new packages")
	print()
	print("v0.0.3")
	print("Changed Language for some reason (changed from spanish to english bc why not)")
	print("Added 3 new commands")
	print()
	print("v0.0.1")
	print("First Release")  


def helloworld():
    print("Hello world!")


def typeeffect():
    message = input("Choose your message: ")

    for letter in message:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.1)

    print()


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def pkg_install(package_name):
    source = os.path.join(BASE_DIR, "packages", package_name)
    destination = os.path.join(BASE_DIR, "installed", package_name)

    if os.path.exists(source):

        if os.path.exists(destination):
            print("The package is already installed.")
            return

        os.makedirs(destination, exist_ok=True)

        for file in os.listdir(source):
            source_file = os.path.join(source, file)
            destination_file = os.path.join(destination, file)
            
            if os.path.isdir(source_file):
                shutil.copytree(source_file, destination_file)
                
            else:
                    shutil.copy2(source_file, destination_file)
                    

            

        print(f"{package_name} installed successfully.")

    else:
        print("Package not found.")
        print("Searching in:", source)


def Pynux():
    start_message = "Welcome to PynuxOS, type !help to see the commands\n"

    for letter in start_message:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.05)

    while True:
        command = input(">>> ")

        if command == "!help":
            help()

        elif command == "Version":
            Version()

        elif command == "helloworld":
            helloworld()

        elif command == "typeeffect":
            typeeffect()

        elif command == "clear":
            clear()

        elif command.startswith("pkg install "):
            package = command.replace("pkg install ", "")
            pkg_install(package)

        elif command == "exit":
            print("Come back soon!")
            break
            
        elif command == "Updates":
        	Updates()
            
        elif command == "About":
            About()    
            
        elif command == "Packages":
            Packages()                                                    
                                 
        elif command.startswith("pkg uninstall "):
            package = command.replace("pkg uninstall ", "")
            pkg_uninstall(package)    
            
        elif command.startswith("goto "):
            new_dir = command.replace("goto ", "")
            goto(new_dir)
            
        elif command.startswith("achlist"):
            parts = command.split(maxsplit=1)
            
            if len(parts) == 1:
                achlist("", CURRENT_DIR)
            else:
                achlist(parts[1], CURRENT_DIR)    
                
        elif command.startswith("view "):
             command = command.removeprefix("view ")
             
             view(CURRENT_DIR, command)
             
        elif command.startswith("newfile "):
            command = command.removeprefix("newfile ")
            
            newfile(command, CURRENT_DIR)
            
        elif command.startswith("remove "):
            parts = command.split()
            
            try:
                if parts[1] == "-r":                   
                   command = command.removeprefix("remove -r ")
                   remove_dir(PROTECTED_DIRS, command, CURRENT_DIR, USR_DIR)
                else:
                    command = command.  removeprefix("remove ")
                    remove(command, CURRENT_DIR)
            except Exception as e:
                 print("ERROR:", e)       
                 
        elif command.startswith("newdir"):
            parts = command.split()
            
            try:
                if parts[1] == "-p":
                    command = command.removeprefix("newdir -p ")
                    newdir_parent(command, CURRENT_DIR, USR_DIR)
                else:
                    command = command.removeprefix("newdir ")
                    newdir(command, CURRENT_DIR, USR_DIR)
            except Exception as e:
                 print("ERROR:", e)      
                 
        elif command.startswith("edit "):
            parts = command.split()
            
            try:
                if parts[1] == "-a":
                    command = command.removeprefix("edit -a ")
                    edit_append(CURRENT_DIR, command)
                else:
                    command = command.removeprefix("edit ")
                    edit(CURRENT_DIR, command)
            except Exception as e:
                print("ERROR: ", e)
            
        else:
            if try_run_app(command) == False:
                print("Enter a valid command")

def try_run_app(command):
    INSTALLED_DIR = os.path.join(BASE_DIR, "installed")
    PROJECTS_DIR = os.path.join(BASE_DIR, "home", "Projects")

    if os.path.exists(os.path.join(INSTALLED_DIR, command)):
        APP_DIR = os.path.join(INSTALLED_DIR, command)
        run_app(APP_DIR)

    elif os.path.exists(os.path.join(PROJECTS_DIR, command)):
        APP_DIR = os.path.join(PROJECTS_DIR, command)
        run_app(APP_DIR)

    else:
        print("Apliccation not found")


def run_app(APP_DIR):
    app_file = os.path.join(APP_DIR, "app.py")

    if not os.path.exists(app_file):
        print("app.py not found")
        return

    try:
        spec = importlib.util.spec_from_file_location(
            "app",
            app_file
        )

        app = importlib.util.module_from_spec(spec)
        sys.modules["app"] = app

        spec.loader.exec_module(app)

        if hasattr(app, "run"):
            app.run()
        else:
            print("The application does not have a run() function.")

    except Exception as e:
        print("Error running application:")
        print(e)
        
        
def goto(command):
    global CURRENT_DIR
    
    new_path = os.path.normpath(os.path.join(CURRENT_DIR, command))

    if os.path.commonpath([new_path, USR_DIR]) != USR_DIR:
        print("Access Denied")
        return

    elif os.path.isdir(new_path):
        CURRENT_DIR = new_path
        print(CURRENT_DIR)

    else:
        print(f"{command}: Doesn't exist or not a directory")
        
def achlist(command, CURRENT_DIR):

    if command == "":
        archives = os.listdir(CURRENT_DIR)

        for archive in archives:
            print(archive)

    else:
        path = os.path.join(CURRENT_DIR, command)

        if os.path.isdir(path):
            path_archives = os.listdir(path)

            for archive in path_archives:
                print(archive)

        else:
            print(f"{command}: Doesn't exist or not a directory")                      
            
def view(CURRENT_DIR, command):
        path = os.path.join(CURRENT_DIR, command)
        
        try:
            if os.path.exists(path):
                if os.path.isdir(path):
                    print(f"{command}: Is a directory")
                else:                    
                    with open(f"{path}", "r") as f:
                           content = f.read()
                           print(content)
                    
            else:
                 print(f"{command}: Doesn't exist")
                 
        except Exception as e:
            print("ERROR: ", e)
            
def newfile(command, CURRENT_DIR):
        path = os.path.join(CURRENT_DIR, command)
        
        if os.path.exists(path):
            print(f"{command} already exists")
        else:
            print(f"{command} created successfully")
        
        open(path, "w").close()
        
        
def remove(command, CURRENT_DIR):
        
        
        path = os.path.join(CURRENT_DIR, command)
        if os.path.isdir(path):
            print(f"{command}: Is a directory")
        else:
            if os.path.exists(path):
                print(f"{command} deleted successfully")    
                os.remove(path)
            else:
                print(f"{command}: doesn't exists")
                
def remove_dir(PROTECTED_DIRS, command, CURRENT_DIR, USR_DIR):

    path = os.path.join(CURRENT_DIR, command)

    if command in PROTECTED_DIRS:
        print("Access Denied")
        return

    if not os.path.exists(path):
        print(f"{command}: doesn't exist")
        return

    if not os.path.isdir(path):
        print(f"{command}: not a directory")
        return

    if os.path.commonpath([USR_DIR, path]) != USR_DIR:
        print("Access Denied")
        return

    shutil.rmtree(path)
    print(f"{command} deleted successfully")
                
def newdir(command, CURRENT_DIR, USR_DIR):
    path = os.path.join(CURRENT_DIR, command)

    if not os.path.exists(path):
        if os.path.commonpath([USR_DIR, path]) != USR_DIR:
            print("Access Denied")
        else:
            os.mkdir(path)
            print(f"{command} created successfully")
    else:
        print(f"{command} already exists")
        
def newdir_parent(command, CURRENT_DIR, USR_DIR):
    path = os.path.join(CURRENT_DIR, command)

    if not os.path.exists(path):
        if os.path.commonpath([USR_DIR, path]) != USR_DIR:
            print("Access Denied")
        else:
            os.makedirs(path)
            print(f"{command} created successfully")
    else:
        print(f"{command} already exists")         
        
def edit(CURRENT_DIR, command):
    path = os.path.join(CURRENT_DIR, command)

    if not os.path.exists(path):
        print(f"{command}: Doesn't exist")
        return

    if os.path.isdir(path):
        print(f"{command}: Is a directory")
        return

    with open(path, "r") as f:
        content = f.read()

    print("--- Current content ---")
    print(content)
    print("-----------------------")
    print("Type :save to save and exit")

    lines = []

    while True:
        line = input()

        if line == ":save":
            break

        lines.append(line)

    with open(path, "w") as f:
        f.write("\n".join(lines))

    print(f"{command} saved successfully.")   
    
                                                                       
def edit_append(CURRENT_DIR, command):
    path = os.path.join(CURRENT_DIR, command)

    if not os.path.exists(path):
        print(f"{command}: Doesn't exist")
        return

    if os.path.isdir(path):
        print(f"{command}: Is a directory")
        return

    with open(path, "r") as f:
        content = f.read()

    print("--- Current content ---")
    print(content)
    print("-----------------------")
    print("Type :save to save and exit")

    lines = []

    while True:
        line = input()

        if line == ":save":
            with open(path, "a") as f:
                f.write("\n")
            break

        lines.append(line)

    with open(path, "a") as f:
        f.write("\n".join(lines))

    print(f"{command} saved successfully.")
    
    
    
filesystem_not_found(USR_DIR)    
Pynux()