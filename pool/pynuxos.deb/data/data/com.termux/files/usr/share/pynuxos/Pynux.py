import os
import sys
import time
import shutil
import importlib
import random


if os.path.exists("/storage/emulated/0/PynuxOS"):
    BASE_DIR = "/storage/emulated/0/PynuxOS"
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def help():
    print("Command list:")
    print("Version: tells you the console version")
    print("Updates: shows the updates of the console")
    print("Packages: shows the list of the packages that can be installed")
    print("About: tells you info of the console")
    print("helloworld: 'Hello World!'")
    print("typeeffect: returns the message with a typing effect")
    print("exit: closes PynuxOS")
    print("!help: shows this list")
    print("clear: clears the screen")
    print("pkg install <name>: installs a package")
    print("pkg uninstall <name>: deletes an installed package")
    print("There is nothing else, this is V0.0.3, what did you expect?")
    
def pkg_uninstall(package_name):
    installed_package = os.path.join(BASE_DIR, "installed", package_name)

    if os.path.exists(installed_package):
        shutil.rmtree(installed_package)
        print(f"{package_name} uninstalled successfully.")

    else:
        print("The package is not installed.")    


def Version():
    print("PynuxOS V0.0.3")
    
def Packages():
    print("Packages")
    print("-------------------")
    print("calculator: it's a calculator")
    
def About():
    print("PynuxOS")    
    print("--ABOUT--")
    print("Author: Unknown")
    print("Version: 0.0.3")
    print("Desc: A Python-based terminal environment for Termux")
    print(f"Your IP: {random.randint(0, 9)}.{random.randint(0, 999)}.{random.randint(0, 99)}.0 (<-- this is random btw")
    
def Updates():
	print("v0.0.3")
	print("Changed Language for some reason")
	print("Added 3 new commands")
	print()
	print("v0.0.1")
	print("First Release")  


def helloworld():
    print("Hello world!")


def typeeffect():
    message = input("Choose your message: ")

    for letter in message:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.1)

    print()


def clear():
    os.system("cls" if os.name == "nt" else "clear")


def pkg_install(package_name):
    source = os.path.join(BASE_DIR, "packages", package_name)
    destination = os.path.join(BASE_DIR, "installed", package_name)

    if os.path.exists(source):

        if os.path.exists(destination):
            print("The package is already installed.")
            return

        os.makedirs(destination, exist_ok=True)

        for file in os.listdir(source):
            source_file = os.path.join(source, file)
            destination_file = os.path.join(destination, file)

            shutil.copy2(source_file, destination_file)

        print(f"{package_name} installed successfully.")

    else:
        print("Package not found.")
        print("Searching in:", source)


def run_app(package_name):
    sys.path.append(BASE_DIR)

    path = f"installed.{package_name}.app"

    try:
        app = importlib.import_module(path)
        app.run()

    except ModuleNotFoundError as e:
        print("The application is not installed.")
        print("Error:", e)

    except AttributeError:
        print("The application does not have a run() function.")


def Pynux():
    start_message = "Welcome to PynuxOS, type !help to see the commands\n"

    for letter in start_message:
        sys.stdout.write(letter)
        sys.stdout.flush()
        time.sleep(0.05)

    while True:
        command = input(">>> ")

        if command == "!help":
            help()

        elif command == "Version":
            Version()

        elif command == "helloworld":
            helloworld()

        elif command == "typeeffect":
            typeeffect()

        elif command == "clear":
            clear()

        elif command.startswith("pkg install "):
            package = command.replace("pkg install ", "")
            pkg_install(package)

        elif command == "calculator":
            run_app("calculator")

        elif command == "exit":
            print("Come back soon!")
            break
            
        elif command == "Updates":
        	Updates()
            
        elif command == "About":
            About()    
            
        elif command == "Packages":
            Packages()                                                    
                                 
        elif command.startswith("pkg uninstall "):
            package = command.replace("pkg uninstall ", "")
            pkg_uninstall(package)    

        else:
            print("Enter a valid command")


Pynux()